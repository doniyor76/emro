'use client'
import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { showToast } from '@/components/ui/Toast'
import { useAppStore } from '@/hooks/useAppStore'

type Lang3 = 'uz' | 'en' | 'ru'

const T = {
  uz: {
    tagline: 'HAYOTINGIZNI SAQLANG · AI TARTIBLESIN',
    email: 'Email', password: 'Parol', login: 'Kirish',
    or: 'yoki', google: 'Google orqali kirish',
    register: 'Yangi hisob yaratish', fullname: 'Ism Familiya',
    create: 'Hisob yaratish', already: 'Allaqachon hisobingiz bormi?',
    back: 'Kirish', emailph: 'siz@email.com', passph: 'Kamida 8 belgi',
    nameph: "To'liq ismingiz", waiting: 'Kutilmoqda...',
    emailConfirm: 'Email tasdiqlash xati yuborildi!',
    wrongCreds: "Email yoki parol noto'g'ri",
  },
  en: {
    tagline: 'SAVE YOUR LIFE · LET AI ORGANIZE',
    email: 'Email', password: 'Password', login: 'Sign In',
    or: 'or', google: 'Continue with Google',
    register: 'Create New Account', fullname: 'Full Name',
    create: 'Create Account', already: 'Already have an account?',
    back: 'Sign In', emailph: 'you@email.com', passph: 'At least 8 chars',
    nameph: 'Your full name', waiting: 'Loading...',
    emailConfirm: 'Check your email for confirmation!',
    wrongCreds: 'Invalid email or password',
  },
  ru: {
    tagline: 'СОХРАНИ ЖИЗНЬ · ПУСТЬ AI ОРГАНИЗУЕТ',
    email: 'Эл. почта', password: 'Пароль', login: 'Войти',
    or: 'или', google: 'Войти через Google',
    register: 'Создать аккаунт', fullname: 'Имя и фамилия',
    create: 'Создать аккаунт', already: 'Уже есть аккаунт?',
    back: 'Войти', emailph: 'вы@email.com', passph: 'Минимум 8 символов',
    nameph: 'Ваше полное имя', waiting: 'Загрузка...',
    emailConfirm: 'Письмо отправлено на почту!',
    wrongCreds: 'Неверный email или пароль',
  },
}

export default function LoginScreen() {
  const { setLang } = useAppStore()
  const [lang, setLang3] = useState<Lang3>('uz')
  const [mode, setMode]     = useState<'login' | 'register'>('login')
  const [loading, setLoading] = useState(false)
  const [googleLoading, setGoogleLoading] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const [email, setEmail]   = useState('')
  const [pass,  setPass]    = useState('')
  const [rName, setRName]   = useState('')
  const [rEmail, setREmail] = useState('')
  const [rPass,  setRPass]  = useState('')

  const t = T[lang]

  function changeLang(l: Lang3) {
    setLang3(l)
    setLang(l === 'ru' ? 'uz' : l) // store only uz/en
  }

  // ── Stars ──────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    let af: number
    const stars = Array.from({ length: 130 }, () => ({
      x: Math.random(), y: Math.random(),
      r: Math.random() * 1.5 + 0.2,
      a: Math.random() * Math.PI * 2,
      sp: Math.random() * 0.004 + 0.001,
    }))
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight }
    resize()
    window.addEventListener('resize', resize)
    const draw = () => {
      af = requestAnimationFrame(draw)
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      stars.forEach(s => {
        s.a += s.sp
        const alpha = (Math.sin(s.a) * 0.5 + 0.5) * 0.7 + 0.1
        ctx.beginPath()
        ctx.arc(s.x * canvas.width, s.y * canvas.height, s.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(180,200,255,${alpha.toFixed(2)})`
        ctx.fill()
      })
    }
    draw()
    return () => { cancelAnimationFrame(af); window.removeEventListener('resize', resize) }
  }, [])

  async function doLogin(e: React.FormEvent) {
    e.preventDefault()
    if (!email.trim() || !pass) { showToast('❗ ' + t.email + ' va ' + t.password); return }
    setLoading(true)
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pass })
    setLoading(false)
    if (error) showToast('❌ ' + (error.message.toLowerCase().includes('invalid') ? t.wrongCreds : error.message))
  }

  async function doReg(e: React.FormEvent) {
    e.preventDefault()
    if (!rName.trim() || !rEmail.trim() || !rPass) { showToast("❗ Barcha maydonlarni to'ldiring"); return }
    if (rPass.length < 8) { showToast('❗ Parol kamida 8 belgi'); return }
    setLoading(true)
    const { data, error } = await supabase.auth.signUp({
      email: rEmail.trim(), password: rPass,
      options: { data: { full_name: rName.trim() } },
    })
    setLoading(false)
    if (error) { showToast('❌ ' + error.message); return }
    if (data.user && !data.session) showToast('📧 ' + t.emailConfirm)
  }

  async function doGoogle() {
    try {
      setGoogleLoading(true)
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo: `${window.location.origin}/`, queryParams: { access_type: 'offline', prompt: 'consent' } },
      })
      if (error) { showToast('❌ ' + error.message); setGoogleLoading(false) }
    } catch { showToast('❌ Tarmoq xatosi'); setGoogleLoading(false) }
  }

  const iField: React.CSSProperties = {
    width: '100%', background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(0,212,255,0.18)', borderRadius: 10,
    padding: '12px 14px', color: 'var(--text)',
    fontSize: '0.92rem', fontFamily: 'var(--font)', outline: 'none',
    transition: 'border-color 0.2s',
  }

  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', overflow: 'hidden' }}>
      <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, zIndex: 0 }} />

      {/* Glow orbs */}
      <div style={{ position: 'absolute', inset: 0, zIndex: 1, pointerEvents: 'none' }}>
        <div style={{ position: 'absolute', width: 500, height: 500, top: -180, left: -120, borderRadius: '50%', background: 'radial-gradient(circle,rgba(0,212,255,0.08) 0%,transparent 70%)', filter: 'blur(60px)', animation: 'orbFloat 9s ease-in-out infinite alternate' }} />
        <div style={{ position: 'absolute', width: 420, height: 420, bottom: -120, right: -80, borderRadius: '50%', background: 'radial-gradient(circle,rgba(79,142,247,0.09) 0%,transparent 70%)', filter: 'blur(80px)', animation: 'orbFloat 7s ease-in-out infinite alternate-reverse' }} />
      </div>

      {/* Rotating border card wrapper */}
      <div style={{ position: 'relative', zIndex: 10, width: 'min(400px, 94vw)' }}>
        {/* Rotating glow border */}
        <div style={{
          position: 'absolute', inset: -2, borderRadius: 22,
          background: 'conic-gradient(from var(--angle), #00d4ff, #4f8ef7, #7c4dff, #ff4d9e, #f0a500, #00e5a0, #00d4ff)',
          animation: 'rotateBorder 3s linear infinite',
          zIndex: -1,
        }} />
        {/* Inner blur mask */}
        <div style={{ position: 'absolute', inset: 0, borderRadius: 20, background: 'var(--bg)', zIndex: -1, filter: 'blur(8px)', opacity: 0.5 }} />

        {/* Card */}
        <div style={{
          background: 'rgba(7,9,16,0.95)',
          border: '1px solid rgba(0,212,255,0.1)',
          borderRadius: 20, padding: '36px 28px',
          backdropFilter: 'blur(40px)',
          boxShadow: '0 40px 100px rgba(0,0,0,0.85)',
          maxHeight: '92vh', overflowY: 'auto',
          position: 'relative',
        }}>

          {/* Lang switcher — 3 ta */}
          <div style={{ position: 'absolute', top: 14, right: 14, display: 'flex', gap: 4 }}>
            {(['uz', 'en', 'ru'] as Lang3[]).map(l => (
              <button key={l} onClick={() => changeLang(l)} style={{
                background: lang === l ? 'rgba(0,212,255,0.15)' : 'rgba(255,255,255,0.05)',
                border: `1px solid ${lang === l ? 'rgba(0,212,255,0.4)' : 'rgba(255,255,255,0.1)'}`,
                borderRadius: 6, color: lang === l ? 'var(--cyan)' : 'rgba(255,255,255,0.5)',
                fontSize: '0.6rem', fontWeight: 700, fontFamily: 'var(--font-mono)',
                padding: '4px 7px', cursor: 'pointer', textTransform: 'uppercase',
                transition: 'all 0.15s',
              }}>{l}</button>
            ))}
          </div>

          {/* Logo */}
          <div style={{ textAlign: 'center', marginBottom: 28 }}>
            <div style={{ width: 56, height: 56, margin: '0 auto 14px', background: 'linear-gradient(135deg,var(--blue),var(--cyan))', borderRadius: 16, display: 'grid', placeItems: 'center', boxShadow: '0 0 40px rgba(0,212,255,0.5)' }}>
              <svg width="26" height="26" viewBox="0 0 32 32" fill="none">
                <path d="M16 3L4 9v8c0 6.6 5.1 12.8 12 14 6.9-1.2 12-7.4 12-14V9L16 3z" fill="rgba(255,255,255,0.1)" stroke="rgba(255,255,255,0.85)" strokeWidth="1.5"/>
                <path d="M11 16l3.5 3.5L21 12" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: 800, background: 'linear-gradient(135deg,#fff 10%,var(--cyan2) 70%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>LifeVault</h1>
            <p style={{ fontSize: '0.6rem', color: 'var(--text3)', marginTop: 6, letterSpacing: '0.12em', textTransform: 'uppercase', fontFamily: 'var(--font-mono)' }}>{t.tagline}</p>
          </div>

          {/* LOGIN */}
          {mode === 'login' && (
            <form onSubmit={doLogin} autoComplete="on">
              <div style={{ marginBottom: 12 }}>
                <label style={{ display: 'block', fontSize: '0.63rem', color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6, fontFamily: 'var(--font-mono)' }}>{t.email}</label>
                <input type="email" autoComplete="email" placeholder={t.emailph} value={email} onChange={e => setEmail(e.target.value)} style={iField}
                  onFocus={e => e.target.style.borderColor = 'rgba(0,212,255,0.5)'}
                  onBlur={e => e.target.style.borderColor = 'rgba(0,212,255,0.18)'}
                />
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: 'block', fontSize: '0.63rem', color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6, fontFamily: 'var(--font-mono)' }}>{t.password}</label>
                <input type="password" autoComplete="current-password" placeholder="••••••••" value={pass} onChange={e => setPass(e.target.value)} style={iField}
                  onFocus={e => e.target.style.borderColor = 'rgba(0,212,255,0.5)'}
                  onBlur={e => e.target.style.borderColor = 'rgba(0,212,255,0.18)'}
                />
              </div>
              <button type="submit" disabled={loading} style={{ width: '100%', padding: '13px', background: 'linear-gradient(135deg,var(--blue),var(--cyan))', border: 'none', borderRadius: 10, color: '#fff', fontSize: '0.95rem', fontWeight: 700, cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.7 : 1, boxShadow: '0 4px 24px rgba(0,212,255,0.3)', fontFamily: 'var(--font)', transition: 'opacity 0.2s' }}>
                {loading ? t.waiting : t.login}
              </button>

              <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '14px 0' }}>
                <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.08)' }} />
                <span style={{ fontSize: '0.68rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>{t.or}</span>
                <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.08)' }} />
              </div>

              <button type="button" onClick={doGoogle} disabled={googleLoading} style={{ width: '100%', padding: '12px 14px', background: googleLoading ? 'rgba(255,255,255,0.03)' : 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 10, color: 'var(--text)', fontSize: '0.9rem', fontWeight: 600, cursor: googleLoading ? 'default' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, opacity: googleLoading ? 0.7 : 1, transition: 'all 0.2s', fontFamily: 'var(--font)' }}>
                {googleLoading ? (
                  <><div style={{ width: 18, height: 18, borderRadius: '50%', border: '2px solid rgba(255,255,255,0.15)', borderTopColor: 'var(--cyan)', animation: 'spin 0.8s linear infinite' }} /><span>{t.waiting}</span></>
                ) : (
                  <><svg width="17" height="17" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.08 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-3.59-13.46-8.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg><span>{t.google}</span></>
                )}
              </button>

              <button type="button" onClick={() => setMode('register')} style={{ width: '100%', padding: '11px', background: 'transparent', border: '1px solid rgba(0,212,255,0.15)', borderRadius: 10, color: 'var(--text2)', fontSize: '0.88rem', cursor: 'pointer', marginTop: 8, fontFamily: 'var(--font)', transition: 'border-color 0.2s' }}>
                {t.register}
              </button>
            </form>
          )}

          {/* REGISTER */}
          {mode === 'register' && (
            <form onSubmit={doReg} autoComplete="on">
              {[
                { label: t.fullname, type: 'text',     ac: 'name',         ph: t.nameph,  val: rName,  set: setRName  },
                { label: t.email,    type: 'email',    ac: 'email',        ph: t.emailph, val: rEmail, set: setREmail },
                { label: t.password, type: 'password', ac: 'new-password', ph: t.passph,  val: rPass,  set: setRPass  },
              ].map(f => (
                <div key={f.label} style={{ marginBottom: 12 }}>
                  <label style={{ display: 'block', fontSize: '0.63rem', color: 'var(--text3)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 6, fontFamily: 'var(--font-mono)' }}>{f.label}</label>
                  <input type={f.type} autoComplete={f.ac} placeholder={f.ph} value={f.val} onChange={e => f.set(e.target.value)} style={iField}
                    onFocus={e => e.target.style.borderColor = 'rgba(0,212,255,0.5)'}
                    onBlur={e => e.target.style.borderColor = 'rgba(0,212,255,0.18)'}
                  />
                </div>
              ))}
              <button type="submit" disabled={loading} style={{ width: '100%', padding: '13px', marginTop: 4, background: 'linear-gradient(135deg,var(--blue),var(--cyan))', border: 'none', borderRadius: 10, color: '#fff', fontSize: '0.95rem', fontWeight: 700, cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.7 : 1, boxShadow: '0 4px 24px rgba(0,212,255,0.3)', fontFamily: 'var(--font)' }}>
                {loading ? t.waiting : t.create}
              </button>
              <div style={{ textAlign: 'center', fontSize: '0.68rem', color: 'var(--text3)', margin: '12px 0 4px', fontFamily: 'var(--font-mono)' }}>{t.already}</div>
              <button type="button" onClick={() => setMode('login')} style={{ width: '100%', padding: '11px', background: 'transparent', border: '1px solid rgba(0,212,255,0.15)', borderRadius: 10, color: 'var(--text2)', fontSize: '0.88rem', cursor: 'pointer', fontFamily: 'var(--font)' }}>{t.back}</button>
            </form>
          )}
        </div>
      </div>

      <style>{`
        @property --angle { syntax: '<angle>'; initial-value: 0deg; inherits: false; }
        @keyframes rotateBorder { to { --angle: 360deg; } }
        @keyframes orbFloat { from{transform:translate(0,0)} to{transform:translate(30px,20px)} }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  )
}
