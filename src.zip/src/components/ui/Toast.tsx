'use client'
// src/components/ui/Toast.tsx
import { useEffect, useState } from 'react'

let _showToast: ((msg: string) => void) | null = null
export function showToast(msg: string) { _showToast?.(msg) }

export default function Toast() {
  const [msg, setMsg] = useState('')
  const [visible, setVisible] = useState(false)
  const timerRef = { current: null as ReturnType<typeof setTimeout> | null }

  useEffect(() => {
    _showToast = (m: string) => {
      setMsg(m)
      setVisible(true)
      if (timerRef.current) clearTimeout(timerRef.current)
      timerRef.current = setTimeout(() => setVisible(false), 2800)
    }
    return () => { _showToast = null }
  }, [])

  if (!visible) return null

  return (
    <div style={{
      position: 'fixed', bottom: 88, left: '50%',
      transform: 'translateX(-50%)',
      background: 'rgba(7,9,18,0.94)',
      border: '1px solid rgba(0,212,255,0.25)',
      borderRadius: 30, padding: '10px 20px',
      fontSize: '0.82rem', color: 'var(--text)',
      whiteSpace: 'nowrap', zIndex: 9999,
      backdropFilter: 'blur(16px)',
      boxShadow: '0 8px 30px rgba(0,0,0,0.6)',
      animation: 'fadeInUp 0.3s cubic-bezier(0.16,1,0.3,1)',
    }}>
      {msg}
    </div>
  )
}
