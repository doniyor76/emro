// src/lib/i18n.ts
import { Lang } from '@/types'

type Translations = Record<string, string>

export const T: Record<Lang, Translations> = {
  uz: {
    login_tagline: 'HAYOTINGIZNI SAQLANG · AI TARTIBLESIN',
    email: 'Email', password: 'Parol', login_btn: 'Kirish',
    or: 'yoki', continue_google: 'Google orqali kirish',
    create_account: 'Yangi hisob yaratish', full_name: 'Ism Familiya',
    full_name_ph: "To'liq ismingiz", min8: 'Kamida 8 belgi',
    reg_btn: 'Hisob yaratish',
    have_account: 'allaqachon hisobingiz bormi?', login_btn2: 'Kirish',
    memories: 'Xotiralar', ai_assistant: 'AI Yordamchi',
    library: 'Kutubxona', library_desc: 'Barcha xotiralar',
    media_gallery: 'Media Galereya', media_desc: 'Rasmlar & videolar',
    notes: 'Eslatmalar', notes_desc: "Fikrlar & rejalar",
    portfolio: 'Portfolio', portfolio_desc: 'Kasbiy profil',
    items_count: 'ta element',
    settings: 'Sozlamalar', language: 'Til', language_desc: 'Interfeys tili',
    dark_theme: "Qorong'u tema", dark_theme_desc: "Koinot uslubida qorong'u fon",
    light_theme: "Yorug' tema", light_theme_desc: 'Toza oq, bulut uslubida',
    stars_anim: 'Yulduzli animatsiya', stars_anim_desc: 'Chat fonidagi yulduzlar',
    close: 'Yopish', profile: 'Profil',
    go_pro: "Pro rejimga o'tish", logout: 'Chiqish',
    notifications: 'Bildirishnomalar', mark_read: "✓ O'qildi",
    notif1: "AI 3 ta xotirani tasniflab qo'ydi",
    notif2: '2 yil oldin: "Tog\' safari" xotirangiz',
    notif3: 'Portfolio yangilandi',
    min5: '5 daqiqa oldin', h1: '1 soat oldin', yesterday: 'Kecha',
    achievement: 'Yutuq',
  },
  en: {
    login_tagline: 'SAVE YOUR LIFE · LET AI ORGANIZE',
    email: 'Email', password: 'Password', login_btn: 'Sign In',
    or: 'or', continue_google: 'Continue with Google',
    create_account: 'Create New Account', full_name: 'Full Name',
    full_name_ph: 'Your full name', min8: 'At least 8 characters',
    reg_btn: 'Create Account',
    have_account: 'already have an account?', login_btn2: 'Sign In',
    memories: 'Memories', ai_assistant: 'AI Assistant',
    library: 'Library', library_desc: 'All memories',
    media_gallery: 'Media Gallery', media_desc: 'Photos & videos',
    notes: 'Notes', notes_desc: 'Thoughts & plans',
    portfolio: 'Portfolio', portfolio_desc: 'Professional profile',
    items_count: 'items',
    settings: 'Settings', language: 'Language', language_desc: 'Interface language',
    dark_theme: 'Dark Theme', dark_theme_desc: 'Space-style dark background',
    light_theme: 'Light Theme', light_theme_desc: 'Clean white, cloud style',
    stars_anim: 'Star Animation', stars_anim_desc: 'Stars in chat background',
    close: 'Close', profile: 'Profile',
    go_pro: 'Upgrade to Pro', logout: 'Sign Out',
    notifications: 'Notifications', mark_read: '✓ Mark Read',
    notif1: 'AI categorized 3 memories',
    notif2: '2 years ago: "Mountain trip" memory',
    notif3: 'Portfolio updated',
    min5: '5 minutes ago', h1: '1 hour ago', yesterday: 'Yesterday',
    achievement: 'Achievement',
  },
}

export function getT(lang: Lang, key: string): string {
  return (T[lang] || T.uz)[key] || key
}
