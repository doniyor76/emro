// src/lib/supabase.ts
import { createClient } from '@supabase/supabase-js'

const SURL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SKEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Custom storage — Edge Tracking Prevention va Safari ITP dan himoya
const _memStore: Record<string, string> = {}
const _safeStorage = {
  getItem: (k: string) => {
    try { return localStorage.getItem(k) } catch { return _memStore[k] ?? null }
  },
  setItem: (k: string, v: string) => {
    try { localStorage.setItem(k, v) } catch { _memStore[k] = v }
  },
  removeItem: (k: string) => {
    try { localStorage.removeItem(k) } catch { delete _memStore[k] }
  },
}

export const supabase = createClient(SURL, SKEY, {
  auth: {
    storage: _safeStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    storageKey: 'lv-auth',
  },
})
