// src/lib/data.ts
import { MemoryItem, MediaItem, BookItem, Note } from '@/types'

export const MEMS: MemoryItem[] = [
  { label: "Tog' safari", date: '2 yil oldin', color: '#0f1b3a', accent: '#4f8ef7' },
  { label: "Tug'ilgan kun", date: '1 yil oldin', color: '#1a0f2e', accent: '#f472b6' },
  { label: 'Diploma', date: '8 oy oldin', color: '#0f2a1a', accent: '#f59e0b' },
  { label: 'Dengiz', date: '3 yil oldin', color: '#0a1f30', accent: '#00d4ff' },
  { label: 'Birinchi kod', date: '4 yil oldin', color: '#1e0f2e', accent: '#a78bfa' },
  { label: "Yangi do'st", date: '6 oy oldin', color: '#1a1e0f', accent: '#34d399' },
  { label: "G'alaba", date: '1 yil oldin', color: '#2a1a0a', accent: '#fbbf24' },
  { label: 'Tong', date: 'Hafta oldin', color: '#1a100f', accent: '#fb923c' },
  { label: 'Bahor', date: '3 oy oldin', color: '#2a0f1a', accent: '#f9a8d4' },
  { label: 'Konsert', date: '5 oy oldin', color: '#1a0a2a', accent: '#818cf8' },
  { label: 'Sayohat', date: '2 oy oldin', color: '#0a1f2a', accent: '#22d3ee' },
  { label: 'Sport', date: '3 hafta oldin', color: '#0f1a2a', accent: '#60a5fa' },
]

export const NOTES: Note[] = [
  { id: 1, title: "Python — O'rganish rejasi", pre: '1-hafta: Asoslar, sintaksis...', tag: 'Reja', date: 'Bugun' },
  { id: 2, title: 'Hayot maqsadlarim 2025', pre: "Sog'lom turmush, yangi til...", tag: 'Maqsad', date: 'Kecha' },
  { id: 3, title: "LifeVault loyiha g'oyalari", pre: 'AI xotira, portfolio, resume...', tag: 'Loyiha', date: '3 kun' },
  { id: 4, title: 'Kitob tavsiyalari', pre: 'Atomic Habits, Deep Work...', tag: 'Kitob', date: '1 hafta' },
  { id: 5, title: 'Haftalik reja', pre: 'Dushanba: React kurs...', tag: 'Reja', date: '1 hafta' },
]

export const MEDIA_ITEMS: MediaItem[] = [
  { emoji: '🏔️', title: "Tog' safari", date: 'Mar 2024', type: 'rasm', color: '#0f1b3a' },
  { emoji: '🌊', title: "Dengiz qirg'og'i", date: 'Avg 2023', type: 'rasm', color: '#0a1f30' },
  { emoji: '🎂', title: "Tug'ilgan kun", date: 'Apr 2024', type: 'rasm', color: '#1a0f2e' },
  { emoji: '🎬', title: 'Sayohat vlog', date: 'Jul 2023', type: 'video', color: '#1e0f2e' },
  { emoji: '🌅', title: 'Tong quyoshi', date: 'Jan 2024', type: 'rasm', color: '#1a100f' },
  { emoji: '🎬', title: 'Hovuz bazmi', date: 'Jun 2023', type: 'video', color: '#0f2a1a' },
  { emoji: '👨‍💻', title: 'Coding session', date: 'Feb 2024', type: 'rasm', color: '#1e0f2e' },
  { emoji: '🏆', title: 'Mukofot marosimi', date: 'Nov 2023', type: 'rasm', color: '#2a1a0a' },
  { emoji: '🌸', title: "Bahor bog'i", date: 'Apr 2023', type: 'rasm', color: '#2a0f1a' },
  { emoji: '🎵', title: 'Konsert kechasi', date: 'Oct 2023', type: 'video', color: '#1a0a2a' },
]

export const BOOKS: BookItem[] = [
  { emoji: '📸', name: 'Rasmlar', count: '142', color: '#1a2a5a' },
  { emoji: '📝', name: 'Eslatmalar', count: '67', color: '#1a3a2a' },
  { emoji: '🏆', name: 'Yutuqlar', count: '32', color: '#3a2a0a' },
  { emoji: '🎬', name: 'Videolar', count: '28', color: '#2a1a3a' },
  { emoji: '⚡', name: 'Skilllar', count: '14', color: '#0a2a3a' },
  { emoji: '📅', name: 'Rejalar', count: '18', color: '#3a1a1a' },
  { emoji: '💡', name: "G'oyalar", count: '45', color: '#1a0a3a' },
  { emoji: '🌍', name: 'Sayohatlar', count: '11', color: '#0a3a1a' },
]
