'use client'
// src/components/ui/LoadingScreen.tsx
import { useEffect, useState } from 'react'

export default function LoadingScreen() {
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 2000)
    const hideOnLoad = () => setTimeout(() => setVisible(false), 500)
    window.addEventListener('load', hideOnLoad)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('load', hideOnLoad)
    }
  }, [])

  if (!visible) return null

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9998,
      background: 'var(--bg)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: 16,
    }}>
      <div style={{
        width: 54, height: 54, borderRadius: 16,
        background: 'linear-gradient(135deg, var(--blue), var(--cyan))',
        display: 'grid', placeItems: 'center',
        boxShadow: '0 0 40px rgba(0,212,255,0.5)',
      }}>
        <svg width="30" height="30" viewBox="0 0 32 32" fill="none">
          <path d="M16 3L4 9v8c0 6.6 5.1 12.8 12 14 6.9-1.2 12-7.4 12-14V9L16 3z" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.7)" strokeWidth="1.5"/>
          <path d="M11 16l3.5 3.5L21 12" stroke="#00d4ff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800,
        background: 'linear-gradient(135deg,#fff,var(--cyan2))',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
        LifeVault
      </div>
      <div style={{ width: 180, height: 3, background: 'rgba(0,212,255,0.15)', borderRadius: 2, overflow: 'hidden' }}>
        <div style={{
          height: '100%', width: '60%', borderRadius: 2,
          background: 'linear-gradient(90deg, var(--blue), var(--cyan))',
          animation: 'shimmer 1.5s ease infinite',
        }} />
      </div>
      <div style={{ fontSize: '0.65rem', color: 'var(--text3)', letterSpacing: '0.16em',
        fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>
        HAYOTINGIZNI SAQLANG
      </div>
    </div>
  )
}
