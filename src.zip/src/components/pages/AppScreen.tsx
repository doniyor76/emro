'use client'
// src/components/pages/AppScreen.tsx
import { useAppStore } from '@/hooks/useAppStore'
import Navbar from '@/components/layout/Navbar'
import BottomNav from '@/components/layout/BottomNav'
import MobileTopbar from '@/components/layout/MobileTopbar'
import HomePage from './HomePage'
import NotesPage from './NotesPage'
import MediaPage from './MediaPage'
import LibraryPage from './LibraryPage'
import PortfolioPage from './PortfolioPage'
import ChatPage from './ChatPage'

export default function AppScreen() {
  const { activeTab } = useAppStore()

  const pages = [
    { id: 'home', Component: HomePage },
    { id: 'notes', Component: NotesPage },
    { id: 'media', Component: MediaPage },
    { id: 'library', Component: LibraryPage },
    { id: 'portfolio', Component: PortfolioPage },
    { id: 'chat', Component: ChatPage },
  ]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
      <MobileTopbar />
      <Navbar />
      <main style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {pages.map(({ id, Component }) => (
          <div key={id} style={{ display: activeTab === id ? 'flex' : 'none', height: '100%', flexDirection: 'column', overflow: 'hidden' }}>
            <Component />
          </div>
        ))}
      </main>
      <BottomNav />
    </div>
  )
}
