'use client'
// src/components/pages/PortfolioPage.tsx
import { useState } from 'react'
import { useAppStore } from '@/hooks/useAppStore'
import { showToast } from '@/components/ui/Toast'
import { supabase } from '@/lib/supabase'

type PfTab = 'skills' | 'ach' | 'projects'

const DEFAULT_SKILLS = ['JavaScript', 'Python', 'React', 'UI/UX Dizayn', 'PostgreSQL', 'Node.js', 'Figma', 'Next.js']

export default function PortfolioPage() {
  const { user } = useAppStore()
  const [pfTab, setPfTab] = useState<PfTab>('skills')
  const [skills, setSkills] = useState(DEFAULT_SKILLS)
  const [editingBio, setEditingBio] = useState(false)
  const [bio, setBio] = useState("LifeVault foydalanuvchisi. Xotiralar, yutuqlar va ko'nikmalar shu yerda saqlanadi.")

  function addSkill() {
    const s = prompt("Yangi skill kiriting:")
    if (s?.trim()) setSkills(prev => [...prev, s.trim()])
  }

  async function doLogout() {
    await supabase.auth.signOut()
  }

  return (
    <div style={{ height: '100%', overflowY: 'auto' }}>
      {/* Cover */}
      <div style={{ height: 140, background: 'linear-gradient(135deg,#0f1b3a,#1a0f2e,#0a1f30)', position: 'relative', flexShrink: 0 }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(0,212,255,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.04) 1px,transparent 1px)', backgroundSize: '28px 28px' }} />
        <button style={{ position: 'absolute', top: 12, right: 12, background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 8, color: 'rgba(255,255,255,0.7)', fontSize: '0.75rem', padding: '5px 10px', cursor: 'pointer' }}>
          ✏️ Fon o'zgartirish
        </button>
      </div>

      <div style={{ padding: '0 20px 80px' }}>
        {/* Avatar + actions */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: -36, marginBottom: 14 }}>
          <div style={{ width: 80, height: 80, borderRadius: 20, background: 'linear-gradient(135deg,var(--blue),var(--cyan))', display: 'grid', placeItems: 'center', fontSize: '1.8rem', fontWeight: 700, border: '3px solid var(--bg)', boxShadow: '0 0 30px rgba(0,212,255,0.3)', color: '#fff', cursor: 'pointer' }}>
            {user?.initial || 'U'}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => showToast('🔗 Link nusxalandi!')} style={{ padding: '7px 14px', borderRadius: 8, background: 'transparent', border: '1px solid rgba(0,212,255,0.2)', color: 'var(--text2)', fontSize: '0.8rem', cursor: 'pointer' }}>🔗 Ulashish</button>
            <button onClick={() => setEditingBio(!editingBio)} style={{ padding: '7px 14px', borderRadius: 8, background: 'linear-gradient(135deg,var(--blue),var(--cyan))', border: 'none', color: '#fff', fontSize: '0.8rem', cursor: 'pointer', fontWeight: 600 }}>✏️ Tahrirlash</button>
          </div>
        </div>

        <div style={{ fontSize: '1.5rem', fontFamily: 'var(--font-display)', fontWeight: 800, marginBottom: 4 }}>{user?.name || 'Abdulloh Karimov'}</div>
        <div style={{ fontSize: '0.82rem', color: 'var(--text3)', marginBottom: 10 }}>@{user?.name?.toLowerCase().replace(' ', '') || 'user'} · lifevault.uz</div>

        {editingBio ? (
          <textarea value={bio} onChange={e => setBio(e.target.value)} onBlur={() => setEditingBio(false)} autoFocus style={{ width: '100%', background: 'rgba(0,212,255,0.04)', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 10, padding: '10px 12px', color: 'var(--text)', fontSize: '0.86rem', fontFamily: 'var(--font)', outline: 'none', resize: 'none', marginBottom: 14 }} rows={3} />
        ) : (
          <p style={{ fontSize: '0.86rem', color: 'var(--text2)', marginBottom: 14, lineHeight: 1.6 }}>{bio}</p>
        )}

        <div style={{ display: 'flex', gap: 16, marginBottom: 20, fontSize: '0.78rem', color: 'var(--text3)' }}>
          <span>📍 Toshkent</span>
          <span>📅 {user?.joined || '2024'} yildan beri</span>
        </div>

        {/* Stats */}
        <div style={{ display: 'flex', gap: 20, marginBottom: 20, padding: '14px 0', borderTop: '1px solid var(--b2)', borderBottom: '1px solid var(--b2)' }}>
          {[
            { n: '0', l: 'Xotira' }, { n: '4', l: 'Yutuq' }, { n: `${skills.length}`, l: 'Skill' }
          ].map(s => (
            <div key={s.l} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '1.5rem', fontWeight: 700, fontFamily: 'var(--font-display)', background: 'linear-gradient(135deg,#fff,var(--cyan))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{s.n}</div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text3)' }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* AI Resume CTA */}
        <div onClick={() => showToast('🤖 AI rezyume tayyorlanmoqda...')} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 14, background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.2)', cursor: 'pointer', marginBottom: 20 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(16,185,129,0.15)', display: 'grid', placeItems: 'center' }}>📄</div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: '0.88rem', fontWeight: 600, color: 'var(--text)' }}>AI Professional Rezyume yaratish</p>
            <span style={{ fontSize: '0.72rem', color: 'var(--text3)' }}>Barcha yutuq va skilllardan avtomatik tuziladi</span>
          </div>
          <span style={{ color: 'var(--text3)' }}>→</span>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: 'rgba(0,212,255,0.04)', border: '1px solid var(--b2)', borderRadius: 10, padding: 4 }}>
          {(['skills', 'ach', 'projects'] as PfTab[]).map(tab => (
            <button key={tab} onClick={() => setPfTab(tab)} style={{ flex: 1, padding: '7px 10px', borderRadius: 7, border: 'none', cursor: 'pointer', fontSize: '0.8rem', fontWeight: pfTab === tab ? 600 : 400, background: pfTab === tab ? 'linear-gradient(135deg,var(--blue),var(--cyan))' : 'transparent', color: pfTab === tab ? '#fff' : 'var(--text3)', transition: 'all 0.2s' }}>
              {tab === 'skills' ? '💡 Skilllar' : tab === 'ach' ? '🏆 Yutuqlar' : '💼 Loyihalar'}
            </button>
          ))}
        </div>

        {pfTab === 'skills' && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {skills.map(s => (
              <span key={s} style={{ padding: '6px 14px', borderRadius: 20, background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.2)', color: 'var(--cyan)', fontSize: '0.82rem', cursor: 'default' }}>{s}</span>
            ))}
            <span onClick={addSkill} style={{ padding: '6px 14px', borderRadius: 20, background: 'rgba(0,212,255,0.04)', border: '1px dashed rgba(0,212,255,0.2)', color: 'var(--text3)', fontSize: '0.82rem', cursor: 'pointer' }}>+ Skill qo'shish</span>
          </div>
        )}

        {pfTab === 'ach' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { icon: '🥇', title: 'Birinchi freelance loyiha — $500 topdim', date: '2024 yil Mart' },
              { icon: '🎓', title: 'TUIT bakalavr diplomi — GPA 3.8', date: '2023 yil Iyun' },
              { icon: '🚀', title: 'Birinchi React ilovam App Store da', date: '2024 yil Sentyabr' },
              { icon: '🏅', title: 'Toshkent Hackathon — 2-o\'rin', date: '2023 yil Noyabr' },
            ].map((a, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px', borderRadius: 14, background: 'var(--card)', border: '1px solid var(--b1)' }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(245,158,11,0.1)', display: 'grid', placeItems: 'center', fontSize: 20, flexShrink: 0 }}>{a.icon}</div>
                <div>
                  <div style={{ fontSize: '0.88rem', fontWeight: 500 }}>{a.title}</div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text3)', marginTop: 3 }}>{a.date}</div>
                </div>
              </div>
            ))}
            <div onClick={() => showToast('➕ Yutuq qo\'shish')} style={{ padding: '12px 16px', borderRadius: 14, border: '1px dashed rgba(0,212,255,0.2)', textAlign: 'center', cursor: 'pointer', color: 'var(--text3)', fontSize: '0.85rem' }}>+ Yangi yutuq qo'shish</div>
          </div>
        )}

        {pfTab === 'projects' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { icon: '🤖', title: 'LifeVault — Personal AI Memory App', tech: 'React · Node.js · Claude API' },
              { icon: '🛒', title: 'E-commerce Platform — 500+ foydalanuvchi', tech: 'Next.js · Stripe · MongoDB' },
            ].map((p, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px', borderRadius: 14, background: 'var(--card)', border: '1px solid var(--b1)' }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(0,212,255,0.08)', display: 'grid', placeItems: 'center', fontSize: 20, flexShrink: 0 }}>{p.icon}</div>
                <div>
                  <div style={{ fontSize: '0.88rem', fontWeight: 500 }}>{p.title}</div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text3)', marginTop: 3 }}>{p.tech}</div>
                </div>
              </div>
            ))}
            <div style={{ padding: '12px 16px', borderRadius: 14, border: '1px dashed rgba(0,212,255,0.2)', textAlign: 'center', cursor: 'pointer', color: 'var(--text3)', fontSize: '0.85rem' }}>+ Loyiha qo'shish</div>
          </div>
        )}
      </div>
    </div>
  )
}
