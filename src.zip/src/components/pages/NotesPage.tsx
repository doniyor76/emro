'use client'
// src/components/pages/NotesPage.tsx
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { showToast } from '@/components/ui/Toast'
import { NOTES } from '@/lib/data'
import { Note } from '@/types'

export default function NotesPage() {
  const [notes, setNotes] = useState<Note[]>(NOTES)
  const [activeId, setActiveId] = useState<number | string>(1)
  const [title, setTitle] = useState("Python — O'rganish rejasi")
  const [body, setBody] = useState(`# Python O'rganish Rejasi\n\n## 1-hafta: Asoslar\n- Sintaksis va o'zgaruvchilar\n- Funksiyalar va looplar\n\n## 2-hafta: OOP\n- Klasslar va ob'ektlar\n- Meros (inheritance)`)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    loadNotes()
  }, [])

  async function loadNotes() {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) return
      const { data } = await supabase.from('items').select('*').eq('user_id', session.user.id).eq('type', 'note').order('created_at', { ascending: false })
      if (data && data.length) {
        const mapped: Note[] = data.map((d: any) => ({ id: d.id, title: d.title || 'Yangi eslatma', pre: (d.content || '').slice(0, 60), tag: 'Eslatma', date: 'Yangi' }))
        setNotes([...NOTES, ...mapped])
      }
    } catch { /* offline */ }
  }

  async function saveNote() {
    showToast('✅ Saqlandi!')
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) return
      if (typeof activeId === 'string') {
        await supabase.from('items').update({ title, content: body }).eq('id', activeId)
      }
    } catch { /* offline */ }
  }

  function openNote(note: Note) {
    setActiveId(note.id)
    setTitle(note.title)
    setBody(note.pre || '')
    if (window.innerWidth < 640) setSidebarOpen(false)
  }

  function newNote() {
    setTitle('Yangi eslatma')
    setBody('')
    setActiveId(Date.now())
    if (window.innerWidth < 640) setSidebarOpen(false)
  }

  const TAG_COLORS: Record<string, string> = {
    Reja: '#4f8ef7', Maqsad: '#f472b6', Loyiha: '#a78bfa', Kitob: '#fbbf24', Eslatma: '#00d4ff',
  }

  return (
    <div style={{ display: 'flex', height: '100%', overflow: 'hidden', position: 'relative' }}>
      {/* Mobile sidebar toggle */}
      <button onClick={() => setSidebarOpen(!sidebarOpen)} style={{ display: 'none', position: 'fixed', bottom: 'calc(70px + 10px)', right: 16, width: 44, height: 44, borderRadius: '50%', zIndex: 75, background: 'linear-gradient(135deg,var(--blue),var(--cyan))', border: 'none', cursor: 'pointer', placeItems: 'center', boxShadow: '0 4px 18px rgba(0,212,255,0.4)' }} className="mobile-only">
        ☰
      </button>

      {/* Sidebar */}
      <div style={{ width: 260, flexShrink: 0, borderRight: '1px solid var(--b1)', background: 'var(--bg2)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ padding: '16px 16px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--b2)' }}>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 600 }}>📝 Notes</h3>
          <button onClick={newNote} style={{ width: 28, height: 28, borderRadius: 7, background: 'rgba(0,212,255,0.12)', border: '1px solid rgba(0,212,255,0.2)', color: 'var(--cyan)', fontSize: 18, cursor: 'pointer', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-mono)' }}>＋</button>
        </div>
        <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--b2)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(0,212,255,0.04)', border: '1px solid var(--b2)', borderRadius: 8, padding: '8px 10px' }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input placeholder="Qidirish..." style={{ background: 'none', border: 'none', outline: 'none', color: 'var(--text)', fontSize: '0.82rem', width: '100%', fontFamily: 'var(--font)' }} />
          </div>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
          {notes.map(note => (
            <div key={note.id} onClick={() => openNote(note)} style={{
              padding: '10px 14px', cursor: 'pointer', borderRadius: 8, margin: '2px 8px',
              background: activeId === note.id ? 'rgba(0,212,255,0.08)' : 'transparent',
              borderLeft: activeId === note.id ? '2px solid var(--cyan)' : '2px solid transparent',
              transition: 'all 0.15s',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                <span style={{ fontSize: '0.84rem', fontWeight: 500, color: 'var(--text)' }}>{note.title}</span>
                <span style={{ fontSize: '0.65rem', color: 'var(--text3)' }}>{note.date}</span>
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text3)', marginBottom: 5 }}>{note.pre}</div>
              <span style={{ fontSize: '0.62rem', padding: '2px 8px', borderRadius: 20, background: (TAG_COLORS[note.tag] || '#4f8ef7') + '22', color: TAG_COLORS[note.tag] || '#4f8ef7', border: `1px solid ${TAG_COLORS[note.tag] || '#4f8ef7'}33` }}>{note.tag}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Editor */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Toolbar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '8px 14px', borderBottom: '1px solid var(--b2)', flexShrink: 0, flexWrap: 'wrap' }}>
          {['B', 'I', 'U'].map(f => (
            <button key={f} onClick={() => document.execCommand(f === 'B' ? 'bold' : f === 'I' ? 'italic' : 'underline')} style={{ width: 28, height: 26, borderRadius: 5, background: 'rgba(0,212,255,0.05)', border: '1px solid var(--b2)', color: 'var(--text2)', cursor: 'pointer', fontSize: '0.78rem', fontWeight: 700 }}>{f}</button>
          ))}
          <div style={{ width: 1, height: 16, background: 'var(--b1)', margin: '0 4px' }} />
          {['H1', 'H2', '— Ajratgich', '☑ Ro\'yxat'].map(t => (
            <button key={t} style={{ height: 26, padding: '0 8px', borderRadius: 5, background: 'rgba(0,212,255,0.05)', border: '1px solid var(--b2)', color: 'var(--text2)', cursor: 'pointer', fontSize: '0.72rem' }}>{t}</button>
          ))}
          <div style={{ marginLeft: 'auto' }}>
            <button onClick={saveNote} style={{ height: 26, padding: '0 12px', borderRadius: 5, background: 'rgba(0,229,160,0.1)', border: '1px solid rgba(0,229,160,0.3)', color: 'var(--green)', cursor: 'pointer', fontSize: '0.72rem', fontWeight: 600 }}>💾 Saqlash</button>
          </div>
        </div>

        {/* Editor body */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '20px 24px', overflow: 'hidden' }}>
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Sarlavha..." style={{ background: 'none', border: 'none', outline: 'none', fontSize: '1.3rem', fontWeight: 700, color: 'var(--text)', fontFamily: 'var(--font-display)', marginBottom: 14, letterSpacing: '-0.02em' }} />
          <textarea value={body} onChange={e => setBody(e.target.value)} placeholder="Yozishni boshlang... AI yordam beradi" style={{ flex: 1, background: 'none', border: 'none', outline: 'none', fontSize: '0.9rem', color: 'var(--text)', fontFamily: 'var(--font-mono)', lineHeight: 1.7, resize: 'none', letterSpacing: '0.01em' }} />
        </div>

        {/* Footer */}
        <div style={{ padding: '8px 14px 12px', borderTop: '1px solid var(--b2)', display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
          <div onClick={() => showToast('⭐ AI tahlil qilmoqda...')} style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '7px 14px', borderRadius: 20, background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', cursor: 'pointer', fontSize: '0.78rem', color: 'var(--gold)' }}>
            ⭐ AI tahlil — reja bo'yicha eslatma yuborsin
          </div>
          <span style={{ fontSize: '0.72rem', color: 'var(--text3)', marginLeft: 'auto' }}>Oxirgi saqlash: hozir</span>
        </div>
      </div>
    </div>
  )
}
