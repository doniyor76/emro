'use client'
// src/components/pages/MediaPage.tsx
import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { showToast } from '@/components/ui/Toast'
import { MEDIA_ITEMS } from '@/lib/data'
import { MediaItem } from '@/types'

type Filter = 'all' | 'rasm' | 'video' | 'ai'

export default function MediaPage() {
  const [filter, setFilter] = useState<Filter>('all')
  const [items, setItems] = useState<MediaItem[]>(MEDIA_ITEMS)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => { loadMedia() }, [])

  async function loadMedia() {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) return
      const { data } = await supabase.from('items').select('*').eq('user_id', session.user.id).in('type', ['rasm', 'video']).order('created_at', { ascending: false }).limit(20)
      if (data && data.length) {
        const mapped: MediaItem[] = data.map((d: any) => ({ emoji: d.type === 'video' ? '🎬' : '🖼️', title: d.title || 'Media', date: new Date(d.created_at).toLocaleDateString(), type: d.type, color: '#0f1b3a' }))
        setItems([...MEDIA_ITEMS, ...mapped])
      }
    } catch { /* offline */ }
  }

  async function onFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files
    if (!files?.length) return
    showToast(`📤 ${files.length} ta fayl yuklanmoqda...`)
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) return
    for (const file of Array.from(files)) {
      const path = `${session.user.id}/${Date.now()}-${file.name}`
      await supabase.storage.from('media').upload(path, file)
      await supabase.from('items').insert({ user_id: session.user.id, type: file.type.startsWith('video') ? 'video' : 'rasm', title: file.name, storage_path: path })
    }
    showToast('✅ Yuklandi!')
    loadMedia()
  }

  const filtered = filter === 'all' ? items : items.filter(i => i.type === filter)

  const FILTERS: Array<{ id: Filter; label: string }> = [
    { id: 'all', label: 'Barchasi' },
    { id: 'rasm', label: '📷 Rasmlar' },
    { id: 'video', label: '🎬 Videolar' },
    { id: 'ai', label: '🤖 AI tanlagan' },
  ]

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ flex: 1, overflowY: 'auto', padding: '20px 20px 80px' }}>
        {/* Header */}
        <div style={{ marginBottom: 20 }}>
          <h2 style={{ fontSize: '1.4rem', fontFamily: 'var(--font-display)', fontWeight: 800, marginBottom: 14, background: 'linear-gradient(135deg,#fff,var(--cyan))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>🖼️ Rasmlar & Videolar</h2>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {FILTERS.map(f => (
              <button key={f.id} onClick={() => setFilter(f.id)} style={{ padding: '6px 14px', borderRadius: 20, border: '1px solid', borderColor: filter === f.id ? 'var(--cyan)' : 'rgba(0,212,255,0.15)', background: filter === f.id ? 'rgba(0,212,255,0.12)' : 'transparent', color: filter === f.id ? 'var(--cyan)' : 'var(--text3)', fontSize: '0.78rem', fontWeight: filter === f.id ? 600 : 400, cursor: 'pointer' }}>{f.label}</button>
            ))}
          </div>
        </div>

        {/* Upload zone */}
        <div onClick={() => fileRef.current?.click()} style={{ border: '2px dashed rgba(0,212,255,0.2)', borderRadius: 16, padding: '24px', textAlign: 'center', cursor: 'pointer', marginBottom: 20, transition: 'all 0.2s', background: 'rgba(0,212,255,0.02)' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>☁️</div>
          <p style={{ fontSize: '0.88rem', color: 'var(--text2)', marginBottom: 4 }}>Rasm yoki video yuklash</p>
          <span style={{ fontSize: '0.72rem', color: 'var(--text3)' }}>Bosing yoki suring — JPG, PNG, MP4 qabul qilinadi</span>
        </div>
        <input ref={fileRef} type="file" multiple accept="image/*,video/*" onChange={onFiles} style={{ display: 'none' }} />

        {/* Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(140px,1fr))', gap: 12 }}>
          {filtered.map((item, i) => (
            <div key={i} onClick={() => showToast(`📖 ${item.title}`)} style={{ borderRadius: 14, overflow: 'hidden', cursor: 'pointer', background: item.color, border: '1px solid rgba(255,255,255,0.06)', transition: 'all 0.25s', aspectRatio: '1', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, position: 'relative' }}>
              <span style={{ fontSize: 36 }}>{item.emoji}</span>
              <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'linear-gradient(to top, rgba(0,0,0,0.8), transparent)', padding: '20px 10px 8px' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 500, color: '#fff' }}>{item.title}</div>
                <div style={{ fontSize: '0.62rem', color: 'rgba(255,255,255,0.5)' }}>{item.date}</div>
              </div>
              {item.type === 'video' && (
                <div style={{ position: 'absolute', top: 8, right: 8, background: 'rgba(0,0,0,0.6)', borderRadius: 6, padding: '2px 6px', fontSize: '0.6rem', color: '#fff' }}>▶ Video</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
