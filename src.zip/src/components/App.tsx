'use client'
// src/components/App.tsx
import { useEffect, useRef, useState } from 'react'
import { useAppStore } from '@/hooks/useAppStore'
import { supabase } from '@/lib/supabase'
import LoginScreen from './pages/LoginScreen'
import AppScreen from './pages/AppScreen'
import Toast from './ui/Toast'
import SettingsModal from './modals/SettingsModal'

export default function App() {
  const { isLoggedIn, setIsLoggedIn, setUser, theme } = useAppStore()
  const initialized = useRef(false)
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    if (initialized.current) return
    initialized.current = true

    async function initSession() {
      try {
        // Google OAuth redirect dan qaytganda hash tokenni process qilish
        const hashParams = new URLSearchParams(window.location.hash.replace('#', '?'))
        const accessToken = hashParams.get('access_token')
        if (accessToken) {
          // Hash ni tozalash
          window.history.replaceState(null, '', window.location.pathname)
        }

        const result = await supabase.auth.getSession()
        const session = result?.data?.session
        if (session) {
          const name = session.user.user_metadata?.full_name ||
                       session.user.user_metadata?.name ||
                       session.user.email!.split('@')[0]
          setUser({
            name,
            email: session.user.email!,
            initial: name[0].toUpperCase(),
            joined: new Date(session.user.created_at).getFullYear().toString(),
          })
          setIsLoggedIn(true)
        }
      } catch {
        // No session — stay on login
      } finally {
        setChecking(false)
      }
    }

    initSession()

    // Auth state listener — Google OAuth redirect ni ham ushlaydi
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session) {
        const name = session.user.user_metadata?.full_name ||
                     session.user.user_metadata?.name ||
                     session.user.email!.split('@')[0]
        setUser({
          name,
          email: session.user.email!,
          initial: name[0].toUpperCase(),
          joined: new Date(session.user.created_at).getFullYear().toString(),
        })
        setIsLoggedIn(true)
        setChecking(false)
      } else {
        setUser(null)
        setIsLoggedIn(false)
        setChecking(false)
      }
    })

    return () => subscription.unsubscribe()
  }, [setIsLoggedIn, setUser])

  // Apply theme to body
  useEffect(() => {
    document.body.classList.toggle('light', theme === 'light')
  }, [theme])

  // Loading screen — faqat birinchi tekshirish paytida
  if (checking) {
    return (
      <div style={{
        position: 'fixed', inset: 0,
        background: 'var(--bg)',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        gap: 16, zIndex: 9999,
      }}>
        {/* Logo */}
        <div style={{
          width: 64, height: 64,
          background: 'linear-gradient(135deg,var(--blue),var(--cyan))',
          borderRadius: 18,
          display: 'grid', placeItems: 'center',
          boxShadow: '0 0 48px rgba(0,212,255,0.45)',
          animation: 'pulse 1.8s ease-in-out infinite',
        }}>
          <svg width="30" height="30" viewBox="0 0 32 32" fill="none">
            <path d="M16 3L4 9v8c0 6.6 5.1 12.8 12 14 6.9-1.2 12-7.4 12-14V9L16 3z"
              fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.9)" strokeWidth="1.5"/>
            <path d="M11 16l3.5 3.5L21 12" stroke="#fff" strokeWidth="2.2"
              strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div style={{
          fontFamily: 'var(--font-display)', fontSize: '1.6rem', fontWeight: 800,
          background: 'linear-gradient(135deg,#fff,var(--cyan2))',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
        }}>LifeVault</div>
        {/* Spinner */}
        <div style={{
          width: 28, height: 28, borderRadius: '50%',
          border: '2.5px solid rgba(0,212,255,0.15)',
          borderTopColor: 'var(--cyan)',
          animation: 'spin 0.8s linear infinite',
        }} />
        <style>{`
          @keyframes spin { to { transform: rotate(360deg); } }
          @keyframes pulse {
            0%,100% { box-shadow: 0 0 48px rgba(0,212,255,0.45); }
            50% { box-shadow: 0 0 72px rgba(0,212,255,0.75); }
          }
        `}</style>
      </div>
    )
  }

  return (
    <>
      {!isLoggedIn ? <LoginScreen /> : <AppScreen />}
      <SettingsModal />
      <Toast />
    </>
  )
}
